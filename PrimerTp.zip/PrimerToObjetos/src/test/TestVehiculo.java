/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import entilles.AutoClasico;
import entilles.Autonuevo;
import entilles.Radio;

/**
 *
 * @author crist
 */
public class TestVehiculo {

    public static void main(String[] args) {
        System.out.println("Auto Clasico sin Radio y sin precio");
        AutoClasico auto1 = new AutoClasico("Bordo", "Volvo", "p1800");
        System.out.println(auto1.toString());

        System.out.println("***************");

        System.out.println("Auto clasico con precio y sin radio");
        AutoClasico auto2 = new AutoClasico("Gris", "Peugeot", "504", 85000);
        System.out.println(auto2.toString());

        System.out.println("***************");

        System.out.println("Peugeot con radio");
        Radio radio1 = new Radio("amarillo", "Philips");
        auto2.setRadio(radio1);
        System.out.println(auto2.toString());
        System.out.println("***************");

        System.out.println("Autonuevo con radio");
        Autonuevo auto4 = new Autonuevo("Blanco", "Chevrolet", "2019", 4569203, "negro", "philips");
     
        System.out.println(auto4);

        System.out.println("***************");

        System.out.println("Auto nuevo");
        Radio radio2 = new Radio("Azul", "Xomax");
        Autonuevo carro1 = new Autonuevo("Negro", "Ford", "mondeo", 4675844);
        carro1.setRadio(radio2);
        System.out.println(carro1);

      
    }
}
