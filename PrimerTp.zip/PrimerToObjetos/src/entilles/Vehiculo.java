
package entilles;

public abstract class Vehiculo {

    String color;
    String marca;
    String modelo;
    float precio;
    Radio radio;

    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    public Vehiculo(String color, String marca, String modelo, float precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.radio = null;
    }

    public Vehiculo(String color, String marca, String modelo, float precio, String colorr, String marca1) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.radio= new Radio(colorr, marca1);
        
    }
public void setRadio(){
    this.radio = radio;
}
    @Override
    public String toString() {
        return "Vehiculo{" + "color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + ", radio=" + radio + '}';
    }

    public String getColor() {
        return color;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public float getPrecio() {
        return precio;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(Radio radio) {
        this.radio =  new Radio(color, modelo);
    }

}