package entilles;

public class Radio {

    private String colorr;
    private String marca1;

    public Radio(String colorr, String marca1) {
        this.colorr = colorr;
        this.marca1 = marca1;
    }

    @Override
    public String toString() {
        return "Radio{" + "colorr=" + colorr + ", marca1=" + marca1 + '}';
    }

    public String getColorr() {
        return colorr;
    }

    public void setColorr(String colorr) {
        this.colorr = colorr;
    }

    public String getMarca1() {
        return marca1;
    }

    public void setMarca1(String marca1) {
        this.marca1 = marca1;
    }

   

   
}
