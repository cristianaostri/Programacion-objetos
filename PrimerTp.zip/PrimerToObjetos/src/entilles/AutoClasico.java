/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entilles;

/**
 *
 * @author crist
 */
public class AutoClasico extends Vehiculo {

    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    public AutoClasico(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

}
