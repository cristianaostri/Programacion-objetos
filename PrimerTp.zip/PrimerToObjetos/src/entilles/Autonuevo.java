/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entilles;

/**
 *
 * @author crist
 */
public class Autonuevo extends Vehiculo {

    public Autonuevo(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    public Autonuevo(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
    }

    public Autonuevo(String color, String marca, String modelo, float precio, String colorr, String marca1) {
        super(color, marca, modelo, precio, colorr, marca1);
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    
   
}
